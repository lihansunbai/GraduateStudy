$(document).ready(function(){
    var desktop = new Desktop({
       div: 'desktop' 
    });
});

